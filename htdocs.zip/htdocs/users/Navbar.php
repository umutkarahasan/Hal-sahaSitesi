
<nav>
    <a style="color: black" href="index.php"><i class="fa-solid fa-house ikon"></i>Anasayfa</a>
    <a style="color: black" href="hakkimizda.php"><i class="fa-solid fa-info ikon"></i>Hakkımızda</a>
    <a style="color: black" href="iletisim.php"><i class="fa-solid fa-map-pin ikon"></i>İletişim</a>
    <a style="color: black" href="profile.php"><i class="fa-solid fa-user ikon"></i>Benim Saham</a>
    <a style="color: black" href="../index.php"><i class="fa-solid fa-arrow-right-from-bracket ikon"></i></a>
</nav>