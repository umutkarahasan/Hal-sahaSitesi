<footer class="footer">
    <div class="footer-left col-md-4 col-sm-6">
        <p class="about">
            <span> Şirket Hakkında</span> Ut congue augue non tellus bibendum, in varius tellus condimentum. In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices eleifend. Integer tellus est, vehicula eu lectus tincidunt,
            ultricies feugiat leo. Suspendisse tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed, viverra massa.
        </p>
        <div class="icons">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-google-plus"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
        </div>
    </div>
    <div class="footer-center col-md-4 col-sm-6">

        <div>
            <i class="fa fa-phone"></i>
            <p> +90 545 581 6315</p>
        </div>
        <div>
            <i class="fa fa-envelope"></i>
            <p><a href="#"> umutkarahasan77@gmail.com</a></p>
        </div>
    </div>
    <div class="footer-right col-md-4 col-sm-6">
        <img src="img/logo.jpg" width="200" height="70" alt="Halısaham" />
        <p class="menu">
            <a href="index.php"> Anasayfa</a> |
            <a href="../sahalar.php"> Sahalar</a> |
            <a href="randevual.php"> Randevu Al</a> |
            <a href="hakkimizda.php"> Hakkımızda</a> |
            <a href="iletisim.php"> İletişim</a> |

        </p>
        <p class="name"> Halısaham  &copy; 2022</p>
    </div>
</footer>
