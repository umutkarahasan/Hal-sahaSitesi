
<nav>
    <a style="color: black" href="index.php"><i class="fa-solid fa-user ikon"></i>ADMİN PANELİ</a>
    <a style="color: black" href="../index.php"><i class="fa-solid fa-arrow-right-from-bracket ikon"></i></a>
    <a style="color: black" href="sahaoptions.php">SAHA İŞLEMLERİ</a>
    <a style="color: black" href="uyeoptions.php">ÜYE İŞLEMLERİ</a>
</nav>