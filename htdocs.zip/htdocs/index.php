<!DOCTYPE html>
    
<html lang="tr">
    <head>
    <meta charset="utf-8">
        <title>Halısaham</title>
        <link rel="stylesheet" href="stylem.css">
        <script src="https://kit.fontawesome.com/bff4935473.js" crossorigin="anonymous"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@1,200&display=swap" rel="stylesheet">
    </head>
    <body>
    <section style="background: white" class="menu" id="menu">
        <div id="logo" >    <img src="img/logo.jpg" width="200" height="70" alt="Halısaham" />
</div>


       <?php
       include("Navbar.php")
       ?>
        
        </section>
    
        
        <section class="" id="anasayfa">
            <div id="black">
                
            </div>
       
        
            <div id="icerik" >
                <h2 style="color: black">Halısaham</h2>
                <hr width=300 align=left>
                <p style="color: white">Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur</p>
            </div>
        </section>












    <?php
    include("Footer.php")
    ?>
    
    </body>
</html>
