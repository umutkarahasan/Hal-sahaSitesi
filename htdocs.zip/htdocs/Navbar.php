<nav style="color: black">
    <a style="color: black" href="index.php"><i class="fa-solid fa-house ikon"></i>Anasayfa</a>
    <a style="color: black" href="sahalar.php"><i class="fa-regular fa-futbol ikon"></i>Sahalar</a>
    <a style="color: black" href="hakkimizda.php"><i class="fa-solid fa-info ikon"></i>Hakkımızda</a>
    <a style="color: black" href="iletisim.php"><i class="fa-solid fa-map-pin ikon"></i>İletişim</a>
    <a style="color: black" href="uyeol.php"><i class="fa-solid fa-user-plus ikon"></i>Üye OL</a>
    <a style="color: black" href="GirisPage.php"><i class="fa-solid fa-user ikon"></i>Giriş</a>
</nav>