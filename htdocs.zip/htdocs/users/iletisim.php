


<html lang="tr">
    <head>
    <meta charset="utf-8">
        <title>Halısaham</title>
        <link rel="stylesheet" href="stylem.css">
        <script src="https://kit.fontawesome.com/bff4935473.js" crossorigin="anonymous"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@1,200&display=swap" rel="stylesheet">
    </head>

    <body>
    <section id="menu">
        <div id="logo">Halısaham</div>
        <?php
        include("Navbar.php")
        ?>

    </section>

    <?php
    include("Footer.php")
    ?>

    </body>
</html>
